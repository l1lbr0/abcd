package com.phonepe.bootcamp.expense.manager.core;

import com.phonepe.bootcamp.expense.manager.core.dao.ExpenseStore;
import com.phonepe.bootcamp.expense.manager.core.service.ExpenseServiceImpl;
import com.phonepe.bootcamp.expense.manager.models.Expense;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import java.util.List;

import static org.mockito.Mockito.when;

@Slf4j
public class TestExpenseService {

    private final ExpenseStore expenseStore;
    private final ExpenseServiceImpl expenseService;

    public TestExpenseService(){
        this.expenseStore = Mockito.mock(ExpenseStore.class);
        this.expenseService = new ExpenseServiceImpl(expenseStore);
    }

    @BeforeEach
    void setup() {
        log.info("This will be executed before every test case");
    }

    @Test
    void testGetListOfExpenses() {
        String dummyUser = "dummyUserId";
        List<Expense> dummyExpenses = List.of(
            Expense.builder().id("id").userId(dummyUser).amount(2).date(1234).build()
        );
        when(expenseStore.getExpenseForUser(dummyUser)).thenReturn(dummyExpenses);
        List<Expense> actualExpenses = expenseService.getExpenseForAnUser(dummyUser);
        Assertions.assertSame(dummyExpenses, actualExpenses);
        Assertions.assertSame(dummyUser, dummyExpenses.get(0).getUserId());
    }

}
