package com.phonepe.bootcamp.expense.manager.core.exception;

public class ExpenseManagerException extends RuntimeException {
    public ExpenseManagerException(String message) {
        super(message);
    }
}

