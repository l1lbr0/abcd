package com.phonepe.bootcamp.expense.manager.core.dao;

import com.google.inject.Singleton;
import com.phonepe.bootcamp.expense.manager.models.Expense;
import lombok.extern.slf4j.Slf4j;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Singleton
@Slf4j
public class MockExpenseStore implements ExpenseStore {

    private final Map<String, Map<String, Expense>> mockExpenseStore = new HashMap<>();

    @Override
    public List<Expense> getExpenseForUser(String userId) {
        return mockExpenseStore.getOrDefault(userId, new HashMap<>()).values().stream().toList();
    }

    @Override
    public void addExpense(Expense expense) {
        mockExpenseStore.putIfAbsent(expense.getUserId(), new HashMap<>());
        mockExpenseStore.get(expense.getUserId()).put(expense.getId(), expense);
    }

    @Override
    public boolean exists(String id, String userId) {
        return mockExpenseStore.getOrDefault(userId, new HashMap<>()).containsKey(id);
    }

}
