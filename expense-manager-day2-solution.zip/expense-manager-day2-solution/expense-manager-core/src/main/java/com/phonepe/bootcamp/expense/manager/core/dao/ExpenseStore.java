package com.phonepe.bootcamp.expense.manager.core.dao;

import com.phonepe.bootcamp.expense.manager.models.Expense;

import java.util.List;

public interface ExpenseStore {

    List<Expense> getExpenseForUser(String userId);
    void addExpense(Expense expense);

    boolean exists(String id, String userId);

}
