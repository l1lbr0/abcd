package com.phonepe.bootcamp.expense.manager.core.service;

import com.google.inject.Inject;
import com.google.inject.Singleton;
import com.phonepe.bootcamp.expense.manager.core.dao.ExpenseStore;
import com.phonepe.bootcamp.expense.manager.core.exception.ExpenseManagerException;
import com.phonepe.bootcamp.expense.manager.models.Expense;
import lombok.extern.slf4j.Slf4j;

import java.util.HashMap;
import java.util.List;

@Singleton
@Slf4j
public class ExpenseServiceImpl implements ExpenseService {

    private final ExpenseStore expenseStore;

    @Inject
    public ExpenseServiceImpl(ExpenseStore expenseStore) {
        this.expenseStore = expenseStore;
    }

    @Override
    public boolean addExpense(Expense expense) {
        if(expenseStore.exists(expense.getId(), expense.getUserId())){
            throw new ExpenseManagerException(String.format("Expense with ID: %s, User ID: %s already exists",
                expense.getId(), expense.getUserId()));
        }
        expenseStore.addExpense(expense);
        return true;
    }

    @Override
    public List<Expense> getExpenseForAnUser(String userId) {
        return expenseStore.getExpenseForUser(userId);
    }


}
