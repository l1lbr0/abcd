package com.phonepe.bootcamp.expense.manager.core.service;

import com.phonepe.bootcamp.expense.manager.models.Expense;

import java.util.List;

public interface ExpenseService {

    boolean addExpense(Expense expense);

    List<Expense> getExpenseForAnUser(String userId);
}
