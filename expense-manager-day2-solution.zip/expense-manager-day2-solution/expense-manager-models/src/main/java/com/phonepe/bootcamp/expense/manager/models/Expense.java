package com.phonepe.bootcamp.expense.manager.models;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class Expense {

    @NotNull
    @NotEmpty
    private String id;

    @NotNull
    @NotEmpty
    private String userId;

    @NotNull
    @NotEmpty
    private String category;

    @Min(1)
    private int amount;

    private long date;

}