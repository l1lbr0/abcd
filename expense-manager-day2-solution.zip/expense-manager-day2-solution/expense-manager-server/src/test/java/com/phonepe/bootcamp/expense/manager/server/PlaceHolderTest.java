package com.phonepe.bootcamp.expense.manager.server;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

public class PlaceHolderTest {

    @Test
    void testPlaceHolderTest() {
        Assertions.assertTrue(true);
    }
}
