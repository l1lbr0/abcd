package com.phonepe.bootcamp.expense.manager.server;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.PropertyAccessor;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.fasterxml.jackson.module.paramnames.ParameterNamesModule;
import com.google.common.base.Strings;
import com.hystrix.configurator.core.HystrixConfigurationFactory;
import com.phonepe.bootcamp.expense.manager.server.common.Constants;
import com.phonepe.bootcamp.expense.manager.server.exception.ExpenseManagerExceptionMapper;
import com.phonepe.bootcamp.expense.manager.server.guice.CoreModule;
import com.phonepe.bootcamp.expense.manager.server.guice.InjectionFactory;
import com.phonepe.bootcamp.expense.manager.server.healthcheck.SampleHealthCheck;
import com.phonepe.bootcamp.expense.manager.server.managed.SampleManaged;
import com.phonepe.bootcamp.expense.manager.server.resources.ExpenseResource;
import com.phonepe.bootcamp.expense.manager.server.resources.Housekeeping;
import io.dropwizard.configuration.EnvironmentVariableSubstitutor;
import io.dropwizard.configuration.SubstitutingSourceProvider;
import io.dropwizard.setup.Bootstrap;
import io.dropwizard.setup.Environment;

public class ExpenseManagerApplication extends BaseApplication<ExpenseManagerConfiguration> {

    public static final String APP_NAME = "expense-manager";

    public static void main(String[] args) throws Exception {
        new ExpenseManagerApplication().run(args);
    }

    @Override
    public String getName() {
        return APP_NAME;
    }

    @Override
    public void initialize(final Bootstrap<ExpenseManagerConfiguration> bootstrap) {

        final var serviceName = getEnv("SERVICE_NAME", APP_NAME);
        bootstrap.setConfigurationSourceProvider(
            new SubstitutingSourceProvider(
                bootstrap.getConfigurationSourceProvider(), new EnvironmentVariableSubstitutor()
            )
        );

        bootstrap.addBundle(oorBundle());
        bootstrap.addBundle(hystrixBundle());
        bootstrap.addBundle(swaggerBundle());
    }

    @Override
    public void run(final ExpenseManagerConfiguration configuration, final Environment environment) {
        environment.getObjectMapper().setSerializationInclusion(JsonInclude.Include.NON_EMPTY);
        environment.getObjectMapper().setSerializationInclusion(JsonInclude.Include.NON_NULL);
        environment.getObjectMapper().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        environment.getObjectMapper().setVisibility(PropertyAccessor.FIELD, JsonAutoDetect.Visibility.ANY);
        environment.getObjectMapper().enable(JsonParser.Feature.ALLOW_UNQUOTED_FIELD_NAMES);
        environment.getObjectMapper().registerModule(new ParameterNamesModule(JsonCreator.Mode.PROPERTIES));
        environment.getObjectMapper().registerModule(new JavaTimeModule());
        environment.jersey().register(new ExpenseManagerExceptionMapper());
        HystrixConfigurationFactory.init(configuration.getHystrixConfig());
        InjectionFactory.init(new CoreModule(configuration));
        environment.jersey().register(InjectionFactory.getInstance(Housekeeping.class));
        environment.jersey().register(InjectionFactory.getInstance(ExpenseResource.class));
        environment.lifecycle().manage(new SampleManaged());
        environment.healthChecks().register(Constants.SAMPLE_HEALTH_CHECK, new SampleHealthCheck());
    }

    private String getEnv(String name, String defaultValue) {
        String value = System.getenv(name);
        return Strings.isNullOrEmpty(value) ? defaultValue : value;
    }
}
