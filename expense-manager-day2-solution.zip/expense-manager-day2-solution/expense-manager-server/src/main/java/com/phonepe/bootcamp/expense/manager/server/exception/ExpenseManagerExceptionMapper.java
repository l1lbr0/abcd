package com.phonepe.bootcamp.expense.manager.server.exception;

import com.phonepe.bootcamp.expense.manager.core.exception.ExpenseManagerException;

import javax.ws.rs.core.Response;
import javax.ws.rs.ext.ExceptionMapper;
import javax.ws.rs.ext.Provider;
import java.util.Map;

@Provider
public class ExpenseManagerExceptionMapper implements ExceptionMapper<ExpenseManagerException> {
    @Override
    public Response toResponse(ExpenseManagerException exception) {
        return Response.status(Response.Status.BAD_REQUEST)
            .entity(Map.of("errorMessage", exception.getMessage()))
            .build();
    }
}