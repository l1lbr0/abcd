package com.phonepe.bootcamp.expense.manager.server;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.hystrix.configurator.config.HystrixConfig;
import io.dropwizard.Configuration;
import lombok.Data;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

@Data
@JsonDeserialize(as = ExpenseManagerConfiguration.class)
public abstract class BaseConfiguration extends Configuration {

    @Valid
    @NotNull
    private HystrixConfig hystrixConfig = new HystrixConfig();

}
