package com.phonepe.bootcamp.expense.manager.server;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import in.vectorpro.dropwizard.swagger.SwaggerBundleConfiguration;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.experimental.FieldNameConstants;

import javax.inject.Named;
import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

@Data
@FieldNameConstants
@JsonIgnoreProperties(ignoreUnknown = true)
public class ExpenseManagerConfiguration extends BaseConfiguration {

    @Valid
    @NotNull
    private SwaggerBundleConfiguration swagger;

}
