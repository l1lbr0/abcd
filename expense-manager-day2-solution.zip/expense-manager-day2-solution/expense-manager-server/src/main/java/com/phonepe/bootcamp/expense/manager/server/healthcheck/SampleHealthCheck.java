package com.phonepe.bootcamp.expense.manager.server.healthcheck;

import com.codahale.metrics.health.HealthCheck;

public class SampleHealthCheck extends HealthCheck {

    @Override
    public Result check(){
        return Result.healthy();
    }

}
