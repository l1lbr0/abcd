package com.phonepe.bootcamp.expense.manager.server;

import in.vectorpro.dropwizard.swagger.SwaggerBundle;
import in.vectorpro.dropwizard.swagger.SwaggerBundleConfiguration;
import io.dropwizard.Application;
import io.dropwizard.oor.OorBundle;
import org.zapodot.hystrix.bundle.HystrixBundle;

abstract class BaseApplication<T extends BaseConfiguration> extends Application<T> {

    HystrixBundle<T> hystrixBundle() {
        // noinspection unchecked
        return HystrixBundle.builder()
                .disableStreamServletInAdminContext()
                .withApplicationStreamPath("/hystrix.stream")
                .build();
    }

    OorBundle<T> oorBundle() {
        return new OorBundle<>() {
            @Override
            public boolean withOor() {
                return false;
            }
        };
    }

    SwaggerBundle<ExpenseManagerConfiguration> swaggerBundle() {
        return new SwaggerBundle<ExpenseManagerConfiguration>() {
            @Override
            protected SwaggerBundleConfiguration getSwaggerBundleConfiguration(ExpenseManagerConfiguration configuration) {
                return configuration.getSwagger();
            }
        };
    }
}
