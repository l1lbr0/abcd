package com.phonepe.bootcamp.expense.manager.server.managed;

import io.dropwizard.lifecycle.Managed;

public class SampleManaged implements Managed {

    @Override
    public void start() throws Exception {
        System.out.println("Sample Managed class started");
    }

    @Override
    public void stop() throws Exception {
        System.out.println("Sample Managed class stopped");
    }

}
