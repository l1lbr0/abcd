package com.phonepe.bootcamp.expense.manager.server.resources;

import com.phonepe.bootcamp.expense.manager.core.service.ExpenseService;
import com.phonepe.bootcamp.expense.manager.models.Expense;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;

import javax.inject.Inject;
import javax.inject.Named;
import javax.validation.Valid;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;


@Slf4j
@Path("/expense")
@Tag(name = "Expense APIs")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
public class ExpenseResource {

    private final ExpenseService expenseService;

    @Inject
    public ExpenseResource(ExpenseService expenseService) {
        this.expenseService = expenseService;
    }

    @Path("/{userId}")
    @GET
    @Operation(summary = "Get all expense of an user")
    public Response getExpenseForAnUser(@PathParam("userId") String userId){
        return Response.ok().entity(expenseService.getExpenseForAnUser(userId)).build();
    }

    @Path("/create")
    @POST
    @Operation(summary = "Add an expense")
    public Response addExpense(@Valid Expense expense){
        return Response.ok().entity(expenseService.addExpense(expense)).build();
    }

}
