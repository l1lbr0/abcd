package com.phonepe.bootcamp.expense.manager.server.guice;

import com.google.inject.AbstractModule;
import com.google.inject.Singleton;
import com.phonepe.bootcamp.expense.manager.core.dao.ExpenseStore;
import com.phonepe.bootcamp.expense.manager.core.dao.MockExpenseStore;
import com.phonepe.bootcamp.expense.manager.core.service.ExpenseService;
import com.phonepe.bootcamp.expense.manager.core.service.ExpenseServiceImpl;
import com.phonepe.bootcamp.expense.manager.server.ExpenseManagerConfiguration;

public class CoreModule extends AbstractModule {

    private final ExpenseManagerConfiguration expenseManagerConfiguration;

    public CoreModule(ExpenseManagerConfiguration expenseManagerConfiguration) {
        this.expenseManagerConfiguration = expenseManagerConfiguration;
    }

    @Override
    protected void configure() {
        bind(ExpenseService.class).to(ExpenseServiceImpl.class).in(Singleton.class);
        bind(ExpenseStore.class).to(MockExpenseStore.class).in(Singleton.class);
    }

}
